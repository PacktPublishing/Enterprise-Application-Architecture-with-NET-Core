﻿using Microsoft.EntityFrameworkCore;

namespace CAS
{
    internal class ApplicationDbContext : DbContext
    {

    }
}