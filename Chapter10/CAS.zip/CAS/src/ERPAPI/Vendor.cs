﻿namespace ERPAPI.Controllers
{
    public class Vendor
    {

        public int VendorID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string PhoneNo { get; set; }
        public string Website { get; set; }
    }
}