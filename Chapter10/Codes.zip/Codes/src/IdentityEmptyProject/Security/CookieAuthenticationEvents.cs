﻿using Microsoft.AspNetCore.Authentication.Cookies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityEmptyProject.Security
{
    public class CookieAuthenticationEvents
    {
        public static void SignIn(CookieSigningInContext context)
        {
            
        }
    }
}
