# README #

### What is this repository for? ###

* This repository basically contains the sample code for the 11th chapter of the book EA apps with .NET Core-
* Code in Chapter 11 for Containerization in Cloud - Front End container
* [Book](https://www.packtpub.com/application-development/enterprise-application-architecture-net-core)

### How do I get set up? ###

* This is a simple single page static application just for demonstration purposes)
* Contains single page code + docker file to generate the static nginx based container out of it

### Who do I talk to? ###

* Code review: By Technical Editor, Technical Reviewer and Peer reviews by co-authors
* Other guidelines: Contact the PACKT publisher for more information. For discussion reach me @habib_a_qureshi