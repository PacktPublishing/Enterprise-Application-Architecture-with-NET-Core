﻿using Chapter2.APP.Interfaces;

namespace Chapter2.APP.UIObjects
{
    public class StatusBar : UIObject, IStatusBar
    {
    }
}
