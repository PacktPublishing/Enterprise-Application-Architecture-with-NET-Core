﻿using Chapter2.APP.Interfaces;

namespace Chapter2.APP.UIObjects
{
    public class UIObject: IUIObject
    {
    }
}
