﻿
namespace Chapter2.APP.Interfaces
{
    public interface IStatusBar : IUIObject
    {
    }
}
