﻿
namespace Chapter2.APP.Interfaces
{
    public interface IScreen : IUIObject
    {
    }
}
