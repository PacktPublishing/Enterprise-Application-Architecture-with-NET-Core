﻿
namespace Chapter2.GoF.State
{
    public class WeatherDays
    {
        public string Weather;
        public int Days;
    }
}
