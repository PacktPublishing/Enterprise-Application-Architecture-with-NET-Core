﻿
namespace Chapter2.GoF.State
{
    public interface IWeatherDaysTeller
    {
        WeatherDays GetWeatherDays();
    }
}
