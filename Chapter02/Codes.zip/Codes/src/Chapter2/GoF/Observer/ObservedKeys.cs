﻿
namespace Chapter2.GoF.Observer
{
    public enum ObservedKeys
    {
        CAPS_LOCK,
        NUM_LOCK,
        SCROLL_LOCK
    }
}
