﻿
namespace Chapter2.GoF.Observer
{
    public interface IKeyObserver
    {
        void Update(object anObject);
    }
}
