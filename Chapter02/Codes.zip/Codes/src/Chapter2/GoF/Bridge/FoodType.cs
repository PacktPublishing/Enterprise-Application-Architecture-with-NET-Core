﻿
namespace Chapter2.GoF.Bridge
{
    public enum FoodType
    {
        Frozen,
        Beef,
        Mutton,
        Chicken,
        Fish,
        Vegetable,
        Liquid
    }
}
