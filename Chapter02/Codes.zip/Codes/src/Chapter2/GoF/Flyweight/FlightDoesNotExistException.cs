﻿using System;

namespace Chapter2.GoF.Flyweight
{
    public class FlightDoesNotExistException : Exception
    {
    }
}
