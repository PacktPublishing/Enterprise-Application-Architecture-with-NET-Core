﻿
namespace Chapter2.GoF.ChainOfResponsibility.Elements
{
    public class WeatherThumbnail
    {
        public byte[] ThumbnailImage;
    }
}