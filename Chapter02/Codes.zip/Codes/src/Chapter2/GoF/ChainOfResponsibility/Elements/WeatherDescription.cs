﻿
namespace Chapter2.GoF.ChainOfResponsibility.Elements
{
    public class WeatherDescription
    {
        public string ShortDescription;
        public string Description;
    }
}