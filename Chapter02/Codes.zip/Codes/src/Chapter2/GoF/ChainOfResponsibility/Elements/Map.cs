﻿
namespace Chapter2.GoF.ChainOfResponsibility.Elements
{
    public class Map
    {
        public string MapURL;
        public byte[] ThumbnailImage;
    }
}