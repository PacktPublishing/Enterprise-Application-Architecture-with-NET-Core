﻿
namespace Chapter2.GoF.ChainOfResponsibility.Elements
{
    public class Temperature
    {
        public int CentigradeTemperature;
        public int FahrenheihtTemperature;
    }
}