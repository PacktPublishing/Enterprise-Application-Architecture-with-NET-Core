﻿
namespace Chapter2.DIC
{
    public interface IAirportFlightSchedulesFactory
    {
        IAirportFlightSchedules CreateAirportFlightSchedules();
    }
}
