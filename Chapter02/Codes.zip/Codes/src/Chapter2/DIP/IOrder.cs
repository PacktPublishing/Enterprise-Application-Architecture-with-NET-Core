﻿
namespace Chapter2.DIP
{
    public interface IOrder
    {
    }
}
