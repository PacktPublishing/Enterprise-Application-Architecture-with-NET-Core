﻿
namespace Chapter2.DIP
{
    public interface IOrderProcessor
    {
        void Process(IOrder order);
    }
}
