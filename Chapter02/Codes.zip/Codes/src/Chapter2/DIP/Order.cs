﻿
namespace Chapter2.DIP
{
    public class Order: IOrder
    {
    }
}
