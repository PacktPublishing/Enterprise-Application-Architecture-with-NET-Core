﻿
namespace Chapter2.LSP
{
    public interface IReadableSettings
    {
        void Load();
    }
}
