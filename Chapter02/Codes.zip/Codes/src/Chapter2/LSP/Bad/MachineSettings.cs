﻿//using Chapter2.LSP;

namespace Chapter2.LSP.Bad
{
    public class MachineSettings : ISettings
    {
        public void Load()
        {
            //Loads the machine settings
        }

        public void Save()
        {
            //Saves the machine settings
        }
    }
}
