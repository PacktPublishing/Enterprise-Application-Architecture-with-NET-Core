﻿//using Chapter2.LSP;

namespace Chapter2.LSP.Bad
{
    public class UserSettings : ISettings
    {
        public void Load()
        {
            //Loads the user settings
        }

        public void Save()
        {
            //Saves the user settings
        }
    }
}
