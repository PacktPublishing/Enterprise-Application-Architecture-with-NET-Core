﻿
namespace Chapter2.LSP
{
    public interface IWriteableSettings
    {
        void Save();
    }
}
