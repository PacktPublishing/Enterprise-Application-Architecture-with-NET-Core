﻿
namespace Chapter2.LSP.Good
{
    public class MachineSettings : IReadableSettings, IWriteableSettings
    {
        public void Load()
        {
            //Loads the machine settings
        }

        public void Save()
        {
            //Saves the machine settings
        }
    }
}
