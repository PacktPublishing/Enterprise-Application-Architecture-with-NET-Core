﻿
namespace Chapter2.LSP.Good
{
    public class ReadOnlySettings : IReadableSettings
    {
        public void Load()
        {
            //Loads the machine settings
        }
    }
}
