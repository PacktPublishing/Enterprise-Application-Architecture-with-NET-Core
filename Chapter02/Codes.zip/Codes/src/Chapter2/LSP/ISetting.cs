﻿
namespace Chapter2.LSP
{
    public interface ISettings
    {
        void Load();
        void Save();
    }
}
