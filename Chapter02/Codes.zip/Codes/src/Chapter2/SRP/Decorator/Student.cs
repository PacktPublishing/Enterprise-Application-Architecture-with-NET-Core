﻿using System;

namespace Chapter2.SRP.Decorator
{
    public class Student
    {
        public string Name;
        public string Id;
        public DateTime DOB;
    }
}
