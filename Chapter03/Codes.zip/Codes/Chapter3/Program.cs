﻿namespace Chapter3
{
    public class Program
    {
        public static void Main(string[] args)
        {
            TestParallel.TestTheParallelProcessing();
        }
    }
}
