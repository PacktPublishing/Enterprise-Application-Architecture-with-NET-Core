﻿
namespace Applications.BusinessLogic.Managers
{
    public interface IBusinessManager
    {
    }
}
