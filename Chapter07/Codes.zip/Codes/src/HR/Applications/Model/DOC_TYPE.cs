﻿namespace Applications.Model
{
    public enum DOC_TYPE
    {
        Passport = 0,
        MedialCertificate
    }
}