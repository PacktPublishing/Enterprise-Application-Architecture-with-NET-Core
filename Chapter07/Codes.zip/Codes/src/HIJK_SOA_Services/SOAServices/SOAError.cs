﻿namespace HIJK.SOA.SOAServices
{
    public class SOAError
    {
    }
}
