﻿
namespace HIJK.SOA.SOAServices
{
    /// <summary>
    /// Carries the basic logging structure in a unified manner across the HIJK SOA Services
    /// </summary>
    public class SOALogStructure
    {
    }
}
