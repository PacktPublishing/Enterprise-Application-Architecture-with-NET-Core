﻿
namespace HIJK.SOA.SOAServices
{
    /// <summary>
    /// SOA Payload carries the payload in a generic way for all SOA services.
    /// Having payload in generic context is useful in variety of way for example error retries and error correction.
    /// </summary>
    public class SOAPayload
    {
    }
}
