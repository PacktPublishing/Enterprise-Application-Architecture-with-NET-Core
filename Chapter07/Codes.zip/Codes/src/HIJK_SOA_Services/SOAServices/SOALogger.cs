﻿
namespace HIJK.SOA.SOAServices
{
    public class SOALogger
    {
        public void Log(SOALogStructure logStructure)
        {
            //
        }
    }
}
