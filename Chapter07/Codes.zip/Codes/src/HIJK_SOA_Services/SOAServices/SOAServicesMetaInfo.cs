﻿namespace HIJK.SOA.SOAServices
{
    /// <summary>
    /// This class contains the SOA services meta information in a generic and unified manner
    /// </summary>
    public class SOAServicesMetaInfo
    {
    }
}
