﻿
namespace DataAccess.Engine
{
    public interface IDataContextCreator
    {
        DataContext GetDataContext();
    }
}
